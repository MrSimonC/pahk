=PAHK=
==Python library to use the AutoHotkey interpreter in python.==

PAHK make possible the use of .ahk (autohotkey script) script within python
in a fully threaded way. It also let python interact with the script at runtime. You might 
find it most useful for task involving macro,hotkeys or windows functions 
(such as getclipboard data). PAHK only works for windows. Here is an example::

{{{
    #!/usr/bin/env python

    from pahk.pahk import Interpreter

    ahk_interpreter = Interpreter() # Create an ahk interpreter
    ahk_script = '^c::MsgBox Hello'  #An ahk script. If Ctrl+c is pressed, brings a msgbox
    ahk_interpreter.execute_script(ahk_script) # Start a thread in the interpreter that run the script

    while 1:
        cmd = raw_input('quit - quit the program\n Press CTRL+C to say hello!\n')
        if cmd.lower() == 'quit':
            break
}}}

==Version Info==

Currently there are 3 versions of pahk:
  # pahk_Win32w - Pahk for x86 and x64 windows. Use Unicode.
  # pahk_Win32a - Pahk for x86 and x64 windows. Use ANSI.
  # pahk_x64w - Pahk only for x64. use Unicode

Every versions have a python 2.x and a python 3.x version.

==Documentation==
The unique class (for now) pahk.Interpreter is documented in the wiki.
http://code.google.com/p/pahk/wiki/Interpreter

==Warnings==

  * Calling AHK functions from python is not yet supported.

  * Calling a function such as quick_exec from a terminated interpreter will raise a windowsError (access violation)

  * Only one version of pahk is supported at a time.

  * Being totally multithreaded, it is recommended to pause the program at least 0.5 seconds after executing an ahk script to let it warms up.

