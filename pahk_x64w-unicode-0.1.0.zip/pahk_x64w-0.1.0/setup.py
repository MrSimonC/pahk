from distutils.core import setup

setup(
    name='pahk_x64w',
    version='0.1.0',
    author='Gabriel Dube',
    author_email='dberube98@gmailcom',
    py_modules=['pahk'],
    url = 'http://code.google.com/p/pahk/',
    data_files = [('Lib/site-packages',['AutoHotkey.dll'])],
    license='LICENSE.txt',
    description='Python library to use the AutoHotkey interpreter in python.',
    long_description=open('README.txt').read()
)